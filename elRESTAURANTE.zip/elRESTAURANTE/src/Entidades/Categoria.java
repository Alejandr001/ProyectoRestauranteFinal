
package Entidades;



public enum Categoria {
    
    
    
    
   Pizzas,
    Lomos,
    Hamburguesas,
    Tacos,
    BebidasSin,
    BebidasCon,
    
}
